﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Crud_Wpf.View
{
    /// <summary>
    /// Lógica de interacción para Inicio.xaml
    /// </summary>
    public partial class Inicio : Window
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void BtnCerrar_Click(object sender, RoutedEventArgs e)
        {
                Application.Current.Shutdown();
        }

        private void BtnMinimizar_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                DragMove();
        }

        private void PreviewMouseLeftBottomDownBG(object sender, MouseButtonEventArgs e)
        {
            BtnMenuLateral.IsChecked = false;
        }

        private void BtnMenuLateral_Checked(object sender, RoutedEventArgs e)
        {

            GridContent.Opacity = 0.1;

            var imagePath = "../../Recursos/Img/MenuHide.png";
            var imageUri = new Uri(imagePath, UriKind.Relative);
            var imageSource = new BitmapImage(imageUri);
            ImageToggleButton.ImageSource = imageSource;


        }

        private void BtnMenuLateral_Unchecked(object sender, RoutedEventArgs e)
        {
            GridContent.Opacity = 1;

            var imagePath = "../../Recursos/Img/MenuOpen.png";
            var imageUri = new Uri(imagePath, UriKind.Relative);
            var imageSource = new BitmapImage(imageUri);
            ImageToggleButton.ImageSource = imageSource;

        }
    }
}
